// Main for assignment creates gui and adds elenemnts to lists
package dandaassignment1;
public class DandAAssignment1 {
    public static void main(String[] args) {
        ParkingManager manager = new ParkingManager();
        Veichle v1 = new Car("ABC123", "John");
        ((Car) v1).setDoors(4);
        Veichle v2 = new ElectricCar("EV456", "Alice", 75);
        // Create 
        manager.AddVeichle(v1);
        manager.AddVeichle(v2);
        // Read
        System.out.println("\nAll Vehicles:");
        manager.DisplayAllVeichles();
        // Update
        Veichle updated = new Car("ABC123", "John Updated");
        ((Car) updated).setDoors(2);
        manager.UpdateVehicle("ABC123", updated);
        System.out.println("\nAfter Update:");
        manager.DisplayAllVeichles();
        // Delete
        manager.RemoveVeichle("EV456");
        System.out.println("\nAfter Delete:");
        manager.DisplayAllVeichles();
        //Queue
        Veichle v3 = new Car("XYZ999", "Mark");
        ((Car) v3).setDoors(2);
        manager.AddToWaitingQueue(v3);
        manager.AssignNextWaitingVeichle();
        // stack
        manager.RemoveVeichle("XYZ999");
        manager.RestoreLastRemovedVeichle();
        System.out.println("\nFinal State:");
        manager.DisplayAllVeichles();
        // Launch GUI
        Gui gui = new Gui();
        gui.setVisible(true);
    }
}