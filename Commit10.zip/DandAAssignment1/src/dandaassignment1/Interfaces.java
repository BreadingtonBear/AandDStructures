
package dandaassignment1;

public class Interfaces {
    
}
