//Creates gui for the app
package dandaassignment1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Gui extends JFrame {
    private ParkingManager manager;
    private JTextField txtReg;
    private JTextField txtOwner;
    private JTextField txtExtra;
    private JComboBox<String> vehicleType;
    private JTextArea outputArea;
    public Gui() {
        manager = new ParkingManager();
        setTitle("Smart Parking System");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        // Top Panel
        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        inputPanel.add(new JLabel("Registration:"));
        txtReg = new JTextField();
        inputPanel.add(txtReg);
        inputPanel.add(new JLabel("Owner:"));
        txtOwner = new JTextField();
        inputPanel.add(txtOwner);
        inputPanel.add(new JLabel("Type:"));
        vehicleType = new JComboBox<>(new String[]{"Car", "ElectricCar"});
        inputPanel.add(vehicleType);
        inputPanel.add(new JLabel("Doors / Battery:"));
        txtExtra = new JTextField();
        inputPanel.add(txtExtra);
        add(inputPanel, BorderLayout.NORTH);
        // Middle Panel
        JPanel buttonPanel = new JPanel();
        JButton btnAdd = new JButton("Add");
        JButton btnRemove = new JButton("Remove");
        JButton btnDisplay = new JButton("Display");
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnRemove);
        buttonPanel.add(btnDisplay);
        add(buttonPanel, BorderLayout.CENTER);
        // Bottom Panel 
        outputArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(outputArea);
        add(scrollPane, BorderLayout.SOUTH);
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String reg = txtReg.getText();
                    String owner = txtOwner.getText();
                    String type = (String) vehicleType.getSelectedItem();
                    int extra = Integer.parseInt(txtExtra.getText());
                    Veichle v;
                    if (type.equals("Car")) {
                        v = new Car(reg, owner);
                        ((Car) v).setDoors(extra);
                    } else {
                        v = new ElectricCar(reg, owner, extra);
                    }
                    manager.AddVeichle(v);
                    outputArea.setText("Vehicle added.\n");
                } catch (Exception ex) {
                    outputArea.setText("Error adding vehicle.\n");
                }
            }
        });
        // REMOVE
        btnRemove.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String reg = txtReg.getText();
                manager.RemoveVeichle(reg);
                outputArea.setText("Vehicle removed.\n");
            }
        });
        // DISPLAY
        btnDisplay.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                StringBuilder sb = new StringBuilder();

                for (Veichle v : manager.GetAllVeichles()) {
                    sb.append(v.GetDetails()).append("\n");
                }

                outputArea.setText(sb.toString());
            }
        });
    }
}