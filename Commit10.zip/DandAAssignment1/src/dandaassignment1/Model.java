
package dandaassignment1;

public class Model {
    
}
