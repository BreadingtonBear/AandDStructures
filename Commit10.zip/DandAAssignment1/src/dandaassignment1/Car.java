//Car class
//extends veichle used to show inheritance and override
package dandaassignment1;
public class Car extends  Veichle{
    private int Doors;

    public Car(String RegistrationNumber, String OwnerName) {
        super(RegistrationNumber, OwnerName);
    }

    public Car() {
    }

    public int getDoors() {
        return Doors;
    }

    public void setDoors(int Doors) {
        this.Doors = Doors;
    }

    public String getRegistrationNumber() {
        return RegistrationNumber;
    }

    public void setRegistrationNumber(String RegistrationNumber) {
        this.RegistrationNumber = RegistrationNumber;
    }

    public String getOwnerName() {
        return OwnerName;
    }

    public void setOwnerName(String OwnerName) {
        this.OwnerName = OwnerName;
    }
    @Override
    public String GetVehicleType(){
        return "Car"; 
    }
    @Override
    public String GetDetails() {
        return super.GetDetails() + ", Doors: " + Doors;
    }
}
