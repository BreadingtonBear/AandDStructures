package dandaassignment1;
import java.util.List;
public interface ReportOperations {
    // Display all vehicles
    void DisplayAllVeichles();
    // Display a single vehicle
    void DisplayVeichle(Veichle veichle);
    // Display list of vehicles (e.g. queue, history)
    void DisplayVeichleList(List<Veichle> veichles);
}