package dandaassignment1;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;
import java.util.ArrayList;

public class ParkingManager implements ParkingOperations, ReportOperations {
    // ADT 1: LinkedList for parked veichles
    private LinkedList<Veichle> ParkedVeichles;
    // ADT 2: Queue for waiting veichles
    private Queue<Veichle> WaitingQueue;
    // ADT 3: Stack for recently removed veichles
    private Stack<Veichle> RecentlyRemoved;
    public ParkingManager() {
        ParkedVeichles = new LinkedList<>();
        WaitingQueue = new LinkedList<>();
        RecentlyRemoved = new Stack<>();
    }

    @Override
    public void AddVeichle(Veichle veichle) {
        if (veichle == null) {
            System.out.println("Cannot add a null veichle.");
            return;
        }

        if (FindVeichleByRegistration(veichle.getRegistrationNumber()) != null) {
            System.out.println("Veichle with registration "
                    + veichle.getRegistrationNumber() + " already exists.");
            return;
        }

        ParkedVeichles.add(veichle);
        System.out.println("Veichle added successfully.");
    }

    @Override
    public List<Veichle> GetAllVeichles() {
        return ParkedVeichles;
    }

    @Override
    public Veichle FindVeichleByRegistration(String RegistrationNumber) {
        for (Veichle veichle : ParkedVeichles) {
            if (veichle.getRegistrationNumber().equalsIgnoreCase(RegistrationNumber)) {
                return veichle;
            }
        }
        return null;
    }

    @Override
    public void UpdateVehicle(String RegistrationNumber, Veichle UpdatedVeichle) {
        for (int i = 0; i < ParkedVeichles.size(); i++) {
            Veichle CurrentVehicle = ParkedVeichles.get(i);

            if (CurrentVehicle.getRegistrationNumber().equalsIgnoreCase(RegistrationNumber)) {
                ParkedVeichles.set(i, UpdatedVeichle);
                System.out.println("Veichle updated successfully.");
                return;
            }
        }

        System.out.println("Veichle not found. Update failed.");
    }

    @Override
    public void RemoveVeichle(String RegistrationNumber) {
        Veichle veichleToRemove = FindVeichleByRegistration(RegistrationNumber);

        if (veichleToRemove != null) {
            ParkedVeichles.remove(veichleToRemove);
            RecentlyRemoved.push(veichleToRemove);
            System.out.println("Veichle removed successfully and added to recently removed stack.");
        } else {
            System.out.println("Veichle not found. Remove failed.");
        }
    }

    @Override
    public void DisplayAllVeichles() {
        if (ParkedVeichles.isEmpty()) {
            System.out.println("No parked veichles found.");
            return;
        }

        System.out.println("Parked Veichles:");
        for (Veichle veichle : ParkedVeichles) {
            DisplayVeichle(veichle);
        }
    }

    @Override
    public void DisplayVeichle(Veichle veichle) {
        if (veichle != null) {
            System.out.println(veichle.GetDetails());
        } else {
            System.out.println("Veichle is null.");
        }
    }

    @Override
    public void DisplayVeichleList(List<Veichle> veichles) {
        if (veichles == null || veichles.isEmpty()) {
            System.out.println("No veichles to display.");
            return;
        }

        for (Veichle veichle : veichles) {
            DisplayVeichle(veichle);
        }
    }

    // Queue methods

    public void AddToWaitingQueue(Veichle veichle) {
        if (veichle == null) {
            System.out.println("Cannot add null veichle to waiting queue.");
            return;
        }

        WaitingQueue.offer(veichle);
        System.out.println("Veichle added to waiting queue.");
    }

    public Veichle AssignNextWaitingVeichle() {
        if (WaitingQueue.isEmpty()) {
            System.out.println("No veichles in waiting queue.");
            return null;
        }

        Veichle NextVeichle = WaitingQueue.poll();
        ParkedVeichles.add(NextVeichle);
        System.out.println("Next waiting veichle assigned to parking.");
        return NextVeichle;
    }

    public List<Veichle> GetWaitingQueueVeichles() {
        return new ArrayList<>(WaitingQueue);
    }

    public void DisplayWaitingQueue() {
        if (WaitingQueue.isEmpty()) {
            System.out.println("Waiting queue is empty.");
            return;
        }

        System.out.println("Waiting Queue:");
        for (Veichle veichle : WaitingQueue) {
            DisplayVeichle(veichle);
        }
    }

    // Stack methods

    public Veichle ViewLastRemovedVeichle() {
        if (RecentlyRemoved.isEmpty()) {
            System.out.println("No recently removed veichles.");
            return null;
        }

        return RecentlyRemoved.peek();
    }

    public Veichle RestoreLastRemovedVeichle() {
        if (RecentlyRemoved.isEmpty()) {
            System.out.println("No veichle to restore.");
            return null;
        }

        Veichle RestoredVeichle = RecentlyRemoved.pop();
        ParkedVeichles.add(RestoredVeichle);
        System.out.println("Last removed veichle restored to parking.");
        return RestoredVeichle;
    }

    public List<Veichle> GetRecentlyRemovedVeichles() {
        return new ArrayList<>(RecentlyRemoved);
    }

    public void DisplayRecentlyRemovedVeichles() {
        if (RecentlyRemoved.isEmpty()) {
            System.out.println("Recently removed stack is empty.");
            return;
        }

        System.out.println("Recently Removed Veichles:");
        for (Veichle veichle : RecentlyRemoved) {
            DisplayVeichle(veichle);
        }
    }
}