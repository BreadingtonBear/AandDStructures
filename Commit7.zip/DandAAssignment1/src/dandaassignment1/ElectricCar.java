//Electric Car
package dandaassignment1;

/**
 *
 * @author Ciaran
 */
public class ElectricCar extends Veichle {

    private int batteryCapacity;

    // Constructor
    public ElectricCar(String registrationNumber, String ownerName, int batteryCapacity) {
        super(registrationNumber, ownerName);
        this.batteryCapacity = batteryCapacity;
    }

    // Getter and Setter
    public int getBatteryCapacity() {
        return batteryCapacity;
    }

    public void setBatteryCapacity(int batteryCapacity) {
        this.batteryCapacity = batteryCapacity;
    }


    @Override
    public String GetVehicleType() {
        return "Electric Car";
    }

    @Override
    public String GetDetails() {
        return super.GetDetails() + ", Battery: " + batteryCapacity + "kWh";
    }
}    

