//Class for all viechels
package dandaassignment1;
public abstract class Veichle {
    protected String RegistrationNumber;
    protected String OwnerName;

    public void setRegistrationNumber(String RegistrationNumber) {
        this.RegistrationNumber = RegistrationNumber;
    }

    public void setOwnerName(String OwnerName) {
        this.OwnerName = OwnerName;
    }
    public String getRegistrationNumber() {
        return RegistrationNumber;
    }

    public String getOwnerName() {
        return OwnerName;
    }

    public Veichle(String RegistrationNumber, String OwnerName) {
        this.RegistrationNumber = RegistrationNumber;
        this.OwnerName = OwnerName;
    }

    public Veichle() {
    }
    public abstract String GetVehicleType();
    public String GetDetails(){
        return "Reg: " + RegistrationNumber + 
               ", Owner: " + OwnerName + 
               ", Type: " + GetVehicleType();
    }
     @Override
    public String toString() {
        return GetDetails();
    }
    
}
