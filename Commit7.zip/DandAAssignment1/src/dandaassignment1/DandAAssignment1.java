package dandaassignment1;

public class DandAAssignment1 {

    public static void main(String[] args) {

        ParkingManager manager = new ParkingManager();

        Veichle car1 = new Car("ABC123", "John");
        ((Car) car1).setDoors(4);

        Veichle car2 = new ElectricCar("EV456", "Alice", 75);

        Veichle car3 = new Car("XYZ999", "Mark");
        ((Car) car3).setDoors(2);

        // LinkedList test
        manager.AddVeichle(car1);
        manager.AddVeichle(car2);
        manager.DisplayAllVeichles();

        // Queue test
        System.out.println("\nAdding veichle to waiting queue:");
        manager.AddToWaitingQueue(car3);
        manager.DisplayWaitingQueue();

        System.out.println("\nAssigning next waiting veichle:");
        manager.AssignNextWaitingVeichle();
        manager.DisplayAllVeichles();

        // Stack test
        System.out.println("\nRemoving EV456:");
        manager.RemoveVeichle("EV456");
        manager.DisplayRecentlyRemovedVeichles();

        System.out.println("\nViewing last removed veichle:");
        Veichle lastRemoved = manager.ViewLastRemovedVeichle();
        if (lastRemoved != null) {
            System.out.println(lastRemoved.GetDetails());
        }

        System.out.println("\nRestoring last removed veichle:");
        manager.RestoreLastRemovedVeichle();
        manager.DisplayAllVeichles();
    }
}