
package dandaassignment1;
import java.util.List;
public interface ParkingOperations {

    // Create
    void AddVeichle(Veichle veichle);

    // Read
    List<Veichle> GetAllVeichles();

    // Update
    void UpdateVehicle(String RegistrationNumber, Veichle UpdatedVeichle);

    // Delete
    void RemoveVeichle(String RegistrationNumber);

    Veichle FindVeichleByRegistration(String RegistrationNumber);
}