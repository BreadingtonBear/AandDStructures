package dandaassignment1;
import java.util.List;
public interface ReportOperations {
    // Display all vehicles
    void DisplayAllVehicles();
    // Display a single vehicle
    void DisplayVehicle(Veichle veichle);
    // Display list of vehicles (e.g. queue, history)
    void DisplayVehicleList(List<Veichle> veichles);
}