package dandaassignment1;
import java.util.LinkedList;
import java.util.List;
public class ParkingManager implements ParkingOperations, ReportOperations {
    private LinkedList<Veichle> ParkedVeichles;
    public ParkingManager() {
        ParkedVeichles = new LinkedList<>();
    }
    @Override
    public void AddVeichle(Veichle veichle) {
        if (veichle == null) {
            System.out.println("Cannot add a null vehicle.");
            return;
        }
        if (FindVeichleByRegistration(veichle.getRegistrationNumber()) != null) {
            System.out.println("Veichle with registration " 
                    + veichle.getRegistrationNumber() + " already exists.");
            return;
        }
        ParkedVeichles.add(veichle);
        System.out.println("Veichle added successfully.");
    }
    @Override
    public List<Veichle> GetAllVeichles() {
        return ParkedVeichles;
    }
    @Override
    public Veichle FindVeichleByRegistration(String RegistrationNumber) {
        for (Veichle veichle : ParkedVeichles) {
            if (veichle.getRegistrationNumber().equalsIgnoreCase(RegistrationNumber)) {
                return veichle;
            }
        }
        return null;
    }

    // UPDATE
    @Override
    public void UpdateVehicle(String RegistrationNumber, Veichle UpdatedVeichle) {
        for (int i = 0; i < ParkedVeichles.size(); i++) {
            Veichle CurrentVehicle = ParkedVeichles.get(i);

            if (CurrentVehicle.getRegistrationNumber().equalsIgnoreCase(RegistrationNumber)) {
                ParkedVeichles.set(i, UpdatedVeichle);
                System.out.println("Veichle updated successfully.");
                return;
            }
        }
        System.out.println("Veichle not found. Update failed.");
    }
    @Override
    public void RemoveVeichle(String RegistrationNumber) {
        Veichle veichleToRemove = FindVeichleByRegistration(RegistrationNumber);

        if (veichleToRemove != null) {
            ParkedVeichles.remove(veichleToRemove);
            System.out.println("Veichle removed successfully.");
        } else {
            System.out.println("Veichle not found. Remove failed.");
        }
    }
    @Override
    public void DisplayAllVeichles() {
        if (ParkedVeichles.isEmpty()) {
            System.out.println("No parked vehicles found.");
            return;
        }

        System.out.println("Parked Vehicles:");
        for (Veichle veichle : ParkedVeichles) {
            DisplayVeichle(veichle);
        }
    }

    @Override
    public void DisplayVeichle(Veichle veichle) {
        if (veichle != null) {
            System.out.println(veichle.GetDetails());
        } else {
            System.out.println("Veichle is null.");
        }
    }
    @Override
    public void DisplayVeichleList(List<Veichle> veichles) {
        if (veichles == null || veichles.isEmpty()) {
            System.out.println("No vehicles to display.");
            return;
        }

        for (Veichle veichle : veichles) {
            DisplayVeichle(veichle);
        }
    }
}