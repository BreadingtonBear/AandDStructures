/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dandaassignment1;

public class DandAAssignment1 {
public static void main(String[] args) {

        ParkingManager manager = new ParkingManager();
        Veichle car1 = new Car("ABC123", "John");
        Veichle car2 = new ElectricCar("EV456", "Alice", 75);
        manager.AddVeichle(car1);
        manager.AddVeichle(car2);
        manager.DisplayAllVeichles();
        System.out.println("\nSearching for ABC123:");
        Veichle found = manager.FindVeichleByRegistration("ABC123");
        if (found != null) {
            System.out.println(found.GetDetails());
        }
        System.out.println("\nUpdating ABC123:");
        Veichle UpdatedCar = new ElectricCar("ABC123", "John Updated", 2);
        manager.UpdateVehicle("ABC123", UpdatedCar);
        manager.DisplayAllVeichles();
        System.out.println("\nRemoving EV456:");
        manager.RemoveVeichle("EV456");
        manager.DisplayAllVeichles();
    }
    
}
