package dandaassignment1;

public class DandAAssignment1 {

    public static void main(String[] args) {
        Gui gui = new Gui();
        gui.setVisible(true);
    }
}